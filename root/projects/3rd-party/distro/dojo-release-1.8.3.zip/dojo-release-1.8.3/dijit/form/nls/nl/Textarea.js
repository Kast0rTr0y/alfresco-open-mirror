//>>built
define("dijit/form/nls/nl/Textarea",({iframeEditTitle:"veld bewerken",iframeFocusTitle:"veldkader bewerken"}));
