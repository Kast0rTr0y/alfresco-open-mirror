define(
"dijit/form/nls/hr/validate", ({
	invalidMessage: "Unesena vrijednost nije važeća.",
	missingMessage: "Potrebna je ova vrijednost.",
	rangeMessage: "Ova vrijednost je izvan raspona."
})
);
