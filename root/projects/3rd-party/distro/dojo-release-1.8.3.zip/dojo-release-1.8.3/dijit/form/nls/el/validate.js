//>>built
define("dijit/form/nls/el/validate",({invalidMessage:"Η τιμή που καταχωρήσατε δεν είναι έγκυρη.",missingMessage:"Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί.",rangeMessage:"Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών."}));
