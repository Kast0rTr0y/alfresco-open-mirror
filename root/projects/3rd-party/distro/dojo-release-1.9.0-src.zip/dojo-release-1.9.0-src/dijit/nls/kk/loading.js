define(
({
	loadingState: "Қотарылуда...",
	errorState: "Кешіріңіз, қате орын алды"
})
);
