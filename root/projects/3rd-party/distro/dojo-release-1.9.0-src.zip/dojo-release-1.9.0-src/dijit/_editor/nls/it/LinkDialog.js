define(
({
	createLinkTitle: "Proprietà collegamento",
	insertImageTitle: "Proprietà immagine",
	url: "URL:",
	text: "Descrizione:",
	target: "Destinazione:",
	set: "Imposta",
	currentWindow: "Finestra corrente",
	parentWindow: "Finestra padre",
	topWindow: "Finestra superiore",
	newWindow: "Nuova finestra"
})
);
